
#!/usr/bin/perl
use strict;
use warnings;

sub hello_world {
    print "Hello, World from subroutine!\n";
}

hello_world();
